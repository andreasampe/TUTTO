# FINDER — Analisi di architettura (FASE A)

Stato: **analisi completata, in attesa dell'approvazione per la FASE 1**.
Niente codice è stato ancora scritto. Nessun file creato all'infuori di questo documento.

## 1. Requisiti chiave

- Funziona **solo in locale** sul Mac, totalmente scollegato da tutto il resto.
- Niente servizi a pagamento, niente API commerciali a consumo, niente dipendenze cloud.
- Generico e modulare: ogni fonte è un modulo indipendente.
- Fonti di esempio: mixdrop.vip, maxfri476.website, deltabit.co, Dropbox e cloud classici aperti.
- Un errore su una fonte non deve bloccare le altre.

## 2. Scelta del linguaggio: Node.js (consigliato)

| | Node.js | PHP |
|---|---|---|
| Richieste HTTP in parallelo a più fonti | native (`fetch`/`undici` già integrati in Node 24) | più work (cURL multi) |
| Scheduler in background | naturale | serve job esterno o cron |
| Dipendenze | 2 pacchetti (SQLite + cron) | più pesanti |
| Funziona sul Mac senza server | `node server.js` | sì, ma serve PHP+SQLite |

FINDER è pesante su I/O asincrono (interrogare 10 fonti contemporaneamente) e su scheduler. **Node.js è la scelta naturale.** PHP è l'alternativa se vuoi stare nel tuo universo.

## 3. Struttura delle cartelle

```
test/finder/
├── src/
│   ├── core/          SearchEngine, QueryParser, Ranker, Deduplicator
│   ├── sources/       Source.js (interfaccia) + Api, Rss, Sitemap, Search, Scraper
│   ├── db/            Database + un repo per ogni tabella
│   ├── scheduler/     Scheduler + Monitor (ricerche salvate automatiche)
│   ├── notifications/ NotificationManager + canali (console, browser, telegram, email)
│   ├── http/          Router + controller (Sources, Search, Searches, Notifications…)
│   ├── security/      UrlValidator (SSRF), RateLimiter, Logger
│   └── utils/         HttpClient (timeout + retry), DateParser, HtmlParser
├── public/            index.html + css/tokens.css + js/*.js (dark mode, zero build)
├── data/              finder.db (SQLite, fuori da Git)
├── tests/
├── finder.js          punto di ingresso
├── package.json
└── README.md
```

## 4. Punti tecnici che contano

- **Interfaccia delle fonti**: ogni fonte implementa `testReachability()`, `search()`, `collectLatest()`. Aggiungere una nuova fonte = aggiungere un file.
- **Dedup**: URL normalizzato (senza fragmento, slash finale, host minuscolo) + hash del contenuto.
- **Node 24 ha `fetch` già integrato** — niente pacchetti HTTP da installare.
- **SQLite con `better-sqlite3`**: un file, veloce, niente server.
- **SSRF protection**: blocco indirizzi privati/loopback, risoluzione DNS con controllo IP.
- **Un errore su una fonte non ferma le altre**: ogni fonte isolata in try/catch.

## 5. Fasi (come richiesto)

1. Struttura, database, interfaccia grafica
2. Gestione fonti (aggiungi/modifica/elimina/verifica)
3. Motore di ricerca multi-fonte
4. Monitoraggio (scheduler e ricerche automatiche)
5. Notifiche e storico
6. Test con fonti pubbliche

## 6. Aperte

- [ ] Node.js va bene come principale? (PHP solo se preferisci)
- [ ] Server in locale (`localhost:3000`) va bene?
- [ ] Quali URL di esempio usare per mixdrop / maxfri / deltabit / Dropbox?
- [ ] Il monitoraggio funziona in background mentre navighi, o solo quando lo avvii tu?