// Inizializzazione app.
'use strict';
window.router.init();