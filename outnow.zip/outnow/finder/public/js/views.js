// Gestione logica dell'interfaccia (Dashboard, Ricerca, Fonti).
'use strict';

const { $, el, fmt, esc, refreshHeader } = window.views;

async function renderDashboard(view) {
  view.append(el('div', { class: 'grid' },
    el('div', { class: 'stat' }, el('div', { class: 'l' }, 'Fonti attive'), el('div', { class: 'v' }, (await API.get('/api/sources')).filter(s => s.enabled).length)),
    el('div', { class: 'stat' }, el('div', { class: 'l' }, 'Notifiche'), el('div', { class: 'v' }, await API.get('/api/notifications/unread').then(r => r.count)))
  ));
  refreshHeader();
}

async function renderSearch(view) {
  const container = el('div', { class: 'search-bar' },
    el('input', { id: 'search-input', placeholder: 'Cosa stai cercando?' }),
    el('button', { onclick: runSearch }, 'CERCA')
  );
  view.append(container, el('div', { id: 'results' }));

  async function runSearch() {
    const q = $('#search-input').value;
    if (!q) return;
    const res = await API.get(`/api/search?q=${encodeURIComponent(q)}`);
    const results = $('#results'); results.innerHTML = '';
    res.results.forEach(r => {
      results.append(el('div', { class: 'result' },
        el('div', { class: 't' }, esc(r.title)),
        el('div', { class: 's' }, esc(r.snippet)),
        el('div', { class: 'f' },
          el('a', { href: r.url, target: '_blank' }, 'APRI FONTE'),
          el('span', {}, fmt(r.detected_at))
        )
      ));
    });
  }
}

async function renderSources(view) {
  const sources = await API.get('/api/sources');
  const list = el('div');
  sources.forEach(s => {
    list.append(el('div', { class: 'row' },
      el('div', {}, el('div', { class: 'name' }, esc(s.name)), el('div', { class: 'meta' }, esc(s.url))),
      el('button', { class: 'btn', onclick: () => testSource(s.id) }, 'TEST')
    ));
  });
  view.append(list);
  async function testSource(id) {
    const res = await API.post(`/api/sources/${id}/test`);
    window.router.toast(res.ok ? 'OK' : 'Errore: ' + res.error, !res.ok);
  }
}

window.renderDashboard = renderDashboard;
window.renderSearch = renderSearch;
window.renderSources = renderSources;
window.renderMonitoring = (view) => view.append(el('div', { class: 'empty' }, 'Monitoraggio...'));
window.renderNotifications = (view) => view.append(el('div', { class: 'empty' }, 'Nessuna notifica'));
window.renderHistory = (view) => view.append(el('div', { class: 'empty' }, 'Cronologia...'));
window.renderSettings = (view) => view.append(el('div', { class: 'empty' }, 'Impostazioni...'));