// Router minimale: gestisce la sidebar e il rendering delle viste.
'use strict';

const VIEWS = ['dashboard', 'search', 'monitoring', 'sources', 'notifications', 'history', 'settings'];
const TITLES = {
  dashboard: 'Dashboard',
  search: 'Ricerca',
  monitoring: 'Monitoraggio',
  sources: 'Fonti',
  notifications: 'Notifiche',
  history: 'Cronologia',
  settings: 'Impostazioni',
};

let current = 'dashboard';

function init() {
  const nav = document.getElementById('nav');
  nav.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-view]');
    if (!b) return;
    e.preventDefault();
    current = b.dataset.view;
    [...nav.children].forEach((c) => c.classList.toggle('active', c === b));
    document.getElementById('view-title').textContent = TITLES[current];
    render();
  });
  render();
}

function toast(msg, isErr) {
  let t = document.querySelector('.toast');
  if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
  t.textContent = msg;
  t.classList.toggle('err', !!isErr);
  clearTimeout(t._t);
  t._t = setTimeout(() => t.remove(), 3500);
}

function render() {
  const view = document.getElementById('view');
  view.innerHTML = '';
  if (current === 'dashboard') return renderDashboard(view);
  if (current === 'search') return renderSearch(view);
  if (current === 'monitoring') return renderMonitoring(view);
  if (current === 'sources') return renderSources(view);
  if (current === 'notifications') return renderNotifications(view);
  if (current === 'history') return renderHistory(view);
  if (current === 'settings') return renderSettings(view);
}

window.router = { init, render, toast, current: () => current };