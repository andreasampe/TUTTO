// Server HTTP in locale. Niente cloud: tutto in un file SQLite.
'use strict';

const express = require('express');
const path = require('path');
const cors = require('cors');

const SourceController = require('./controllers/SourceController');
const SearchController = require('./controllers/SearchController');
const NotificationController = require('./controllers/NotificationController');
const Monitor = require('../scheduler/Monitor');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Interfaccia grafica
app.use(express.static(path.join(__dirname, '..', '..', 'public')));

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.get('/api/sources', SourceController.list);
app.get('/api/sources/:id', SourceController.get);
app.post('/api/sources', SourceController.create);
app.put('/api/sources/:id', SourceController.update);
app.delete('/api/sources/:id', SourceController.remove);
app.post('/api/sources/:id/test', SourceController.test);

app.get('/api/searches', SearchController.list);
app.get('/api/searches/:id', SearchController.get);
app.post('/api/searches', SearchController.create);
app.put('/api/searches/:id', SearchController.update);
app.delete('/api/searches/:id', SearchController.remove);
app.post('/api/searches/:id/run', SearchController.runNow);

app.get('/api/search', SearchController.run);
app.get('/api/notifications', NotificationController.list);
app.get('/api/notifications/unread', NotificationController.unreadCount);
app.post('/api/notifications/:id/read', NotificationController.markRead);
app.post('/api/notifications/read-all', NotificationController.markAllRead);

const monitor = new Monitor();
// Controllo automatico periodico ogni minuto.
setInterval(() => {
  monitor.runAll().catch((err) => console.error('[Monitor] errore:', err.message));
}, 60 * 1000);

app.get('/api/monitor/run', async (req, res) => {
  await monitor.runAll();
  res.json({ ok: true });
});

app.get('/api/monitor/run/:id', async (req, res) => {
  await monitor.runNow(Number(req.params.id));
  res.json({ ok: true });
});

// Fallback SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', '..', 'public', 'index.html'));
});

module.exports = app;