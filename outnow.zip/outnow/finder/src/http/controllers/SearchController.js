// Controller per le ricerche salvate e la ricerca manuale.
'use strict';

const SearchRepo = require('../../db/repos/SearchRepo');
const ResultRepo = require('../../db/repos/ResultRepo');
const SearchEngine = require('../../core/SearchEngine');

const SearchController = {
  list(req, res) {
    res.json(SearchRepo.all());
  },

  get(req, res) {
    const s = SearchRepo.findById(Number(req.params.id));
    if (!s) return res.status(404).json({ error: 'Ricerca non trovata' });
    res.json(s);
  },

  create(req, res) {
    const { name, keyword, frequency, source_ids } = req.body;
    if (!name || !keyword) return res.status(400).json({ error: 'Nome e parola chiave sono obbligatori' });
    const ids = (source_ids || '').split(',').map(Number).filter(Boolean);
    const r = SearchRepo.create({ name, keyword, frequency: frequency || 1800, source_ids: ids });
    res.json({ id: r.lastInsertRowid });
  },

  update(req, res) {
    const { name, keyword, frequency, source_ids } = req.body;
    const ids = source_ids === undefined ? undefined : (source_ids || '').split(',').map(Number).filter(Boolean);
    const r = SearchRepo.update(Number(req.params.id), { name, keyword, frequency, source_ids: ids });
    res.json({ changes: r.changes });
  },

  remove(req, res) {
    const r = SearchRepo.remove(Number(req.params.id));
    res.json({ changes: r.changes });
  },

  async run(req, res) {
    const { q, source_ids } = req.query;
    if (!q) return res.status(400).json({ error: 'Parametro q obbligatorio' });
    const ids = (source_ids || '').split(',').map(Number).filter(Boolean) || null;
    const { results, errors } = await SearchEngine.search(q, { sourceIds: ids });
    res.json({ results, errors });
  },

  async runNow(req, res) {
    const monitor = require('../../scheduler/Monitor');
    await monitor.runNow(Number(req.params.id));
    res.json({ ok: true });
  },
};

module.exports = SearchController;