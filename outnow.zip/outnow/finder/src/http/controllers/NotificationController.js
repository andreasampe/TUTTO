// Controller per le notifiche.
'use strict';

const NotificationRepo = require('../../db/repos/NotificationRepo');

const NotificationController = {
  list(req, res) {
    res.json(NotificationRepo.all({ limit: 100 }));
  },

  unreadCount(req, res) {
    res.json({ count: NotificationRepo.unreadCount() });
  },

  markRead(req, res) {
    res.json({ changes: NotificationRepo.markRead(Number(req.params.id)) });
  },

  markAllRead(req, res) {
    res.json({ changes: NotificationRepo.markAllRead() });
  },
};

module.exports = NotificationController;