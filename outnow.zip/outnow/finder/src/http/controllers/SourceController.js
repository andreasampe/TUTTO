// Controller per le fonti.
'use strict';

const SourceRepo = require('../../db/repos/SourceRepo');
const SourceFactory = require('../../sources/SourceFactory');

const SourceController = {
  list(req, res) {
    res.json(SourceRepo.all());
  },

  get(req, res) {
    const s = SourceRepo.findById(Number(req.params.id));
    if (!s) return res.status(404).json({ error: 'Fonte non trovata' });
    res.json(s);
  },

  create(req, res) {
    const { name, url, type, method, frequency } = req.body;
    if (!name || !url) return res.status(400).json({ error: 'Nome e URL sono obbligatori' });
    const r = SourceRepo.create({ name, url, type: type || 'scraper', method: method || 'scraper', frequency: frequency || 3600 });
    res.json({ id: r.lastInsertRowid });
  },

  update(req, res) {
    const r = SourceRepo.update(Number(req.params.id), req.body);
    res.json({ changes: r.changes });
  },

  remove(req, res) {
    const r = SourceRepo.remove(Number(req.params.id));
    res.json({ changes: r.changes });
  },

  async test(req, res) {
    const s = SourceRepo.findById(Number(req.params.id));
    if (!s) return res.status(404).json({ error: 'Fonte non trovata' });
    const src = SourceFactory.create(s);
    const result = await src.testReachability();
    res.json(result);
  },
};

module.exports = SourceController;