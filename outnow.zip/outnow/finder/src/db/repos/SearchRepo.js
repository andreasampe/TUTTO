// Operazioni su `searches` e `search_sources`.
'use strict';

const db = require('../Database');

const SearchRepo = {
  all() {
    return db.prepare(`
      SELECT s.*, COUNT(ss.source_id) AS sources_count
      FROM searches s
      LEFT JOIN search_sources ss ON ss.search_id = s.id
      GROUP BY s.id ORDER BY s.id
    `).all();
  },

  findById(id) {
    return db.prepare(`
      SELECT s.*, GROUP_CONCAT(ss.source_id) AS source_ids
      FROM searches s
      LEFT JOIN search_sources ss ON ss.search_id = s.id
      WHERE s.id = ?
      GROUP BY s.id
    `).get(id);
  },

  create({ name, keyword, frequency, source_ids }) {
    const insert = db.transaction((name, keyword, frequency, source_ids) => {
      const r = db.prepare('INSERT INTO searches (name, keyword, frequency) VALUES (?, ?, ?)')
        .run(name, keyword, frequency || 1800);
      const sid = r.lastInsertRowid;
      const link = db.prepare('INSERT OR IGNORE INTO search_sources (search_id, source_id) VALUES (?, ?)');
      for (const sid2 of source_ids || []) link.run(sid, sid2);
      return sid;
    });
    return insert(name, keyword, frequency, source_ids);
  },

  update(id, { name, keyword, frequency, source_ids }) {
    const update = db.transaction((id, name, keyword, frequency, source_ids) => {
      const fields = [];
      const values = [];
      if (name !== undefined) { fields.push('name = ?'); values.push(name); }
      if (keyword !== undefined) { fields.push('keyword = ?'); values.push(keyword); }
      if (frequency !== undefined) { fields.push('frequency = ?'); values.push(frequency); }
      if (fields.length) { values.push(id); db.prepare(`UPDATE searches SET ${fields.join(', ')} WHERE id = ?`).run(...values); }
      if (source_ids !== undefined) {
        db.prepare('DELETE FROM search_sources WHERE search_id = ?').run(id);
        const link = db.prepare('INSERT OR IGNORE INTO search_sources (search_id, source_id) VALUES (?, ?)');
        for (const sid of source_ids) link.run(id, sid);
      }
    });
    return update(id, name, keyword, frequency, source_ids);
  },

  remove(id) {
    return db.prepare('DELETE FROM searches WHERE id = ?').run(id);
  },

  insertHistory(searchId, keyword, resultsCount) {
    return db.prepare('INSERT INTO search_history (search_id, keyword, results_count) VALUES (?, ?, ?)')
      .run(searchId, keyword, resultsCount);
  },
};

module.exports = SearchRepo;