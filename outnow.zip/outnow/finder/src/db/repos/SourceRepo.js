// Operazioni su `sources`. Niente SQL crudo qui: solo metodi.
'use strict';

const db = require('../Database');

const SourceRepo = {
  all() {
    return db.prepare('SELECT * FROM sources ORDER BY id').all();
  },

  enabled() {
    return db.prepare('SELECT * FROM sources WHERE enabled = 1 ORDER BY id').all();
  },

  findById(id) {
    return db.prepare('SELECT * FROM sources WHERE id = ?').get(id);
  },

  create({ name, url, type, method, frequency }) {
    const stmt = db.prepare(`
      INSERT INTO sources (name, url, type, method, frequency)
      VALUES (?, ?, ?, ?, ?)
    `);
    return stmt.run(name, url, type, method, frequency || 3600);
  },

  update(id, { name, url, type, method, frequency, enabled }) {
    const fields = [];
    const values = [];
    if (name !== undefined) { fields.push('name = ?'); values.push(name); }
    if (url !== undefined) { fields.push('url = ?'); values.push(url); }
    if (type !== undefined) { fields.push('type = ?'); values.push(type); }
    if (method !== undefined) { fields.push('method = ?'); values.push(method); }
    if (frequency !== undefined) { fields.push('frequency = ?'); values.push(frequency); }
    if (enabled !== undefined) { fields.push('enabled = ?'); values.push(enabled ? 1 : 0); }
    if (fields.length === 0) return { changes: 0 };
    values.push(id);
    return db.prepare(`UPDATE sources SET ${fields.join(', ')} WHERE id = ?`).run(...values);
  },

  remove(id) {
    return db.prepare('DELETE FROM sources WHERE id = ?').run(id);
  },

  setLastCheck(id, error = null) {
    return db.prepare('UPDATE sources SET last_check = strftime(\'%s\',\'now\'), last_error = ? WHERE id = ?').run(error, id);
  },
};

module.exports = SourceRepo;