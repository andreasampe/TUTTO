// Operazioni su `notifications`.
'use strict';

const db = require('../Database');

const NotificationRepo = {
  add({ type, title, body }) {
    return db.prepare('INSERT INTO notifications (type, title, body) VALUES (?, ?, ?)').run(type, title, body);
  },

  all({ limit = 50 } = {}) {
    return db.prepare('SELECT * FROM notifications ORDER BY id DESC LIMIT ?').all(limit);
  },

  unreadCount() {
    return db.prepare('SELECT COUNT(*) AS c FROM notifications WHERE "read" = 0').get().c;
  },

  markRead(id) {
    return db.prepare('UPDATE notifications SET "read" = 1 WHERE id = ?').run(id);
  },

  markAllRead() {
    return db.prepare('UPDATE notifications SET "read" = 1 WHERE "read" = 0').run();
  },
};

module.exports = NotificationRepo;