// Operazioni su `results`.
'use strict';

const db = require('../Database');

const ResultRepo = {
  upsert({ search_id, source_id, title, url, snippet, published_at }) {
    const stmt = db.prepare(`
      INSERT INTO results (search_id, source_id, title, url, snippet, published_at, is_new)
      VALUES (?, ?, ?, ?, ?, ?, 1)
      ON CONFLICT(search_id, url) DO UPDATE SET
        title=excluded.title,
        snippet=excluded.snippet,
        published_at=excluded.published_at,
        detected_at=strftime('%s','now'),
        is_new=1
    `);
    return stmt.run(search_id, source_id, title, url, snippet, published_at);
  },

  markOld() {
    return db.prepare("UPDATE results SET is_new = 0 WHERE is_new = 1 AND detected_at < strftime('%s','now') - 86400").run();
  },

  forSearch(searchId, { limit = 50, offset = 0, sort = 'detected_at' } = {}) {
    const order = sort === 'published_at' ? 'published_at' : 'detected_at';
    return db.prepare(`
      SELECT * FROM results
      WHERE search_id = ?
      ORDER BY ${order} DESC
      LIMIT ? OFFSET ?
    `).all(searchId, limit, offset);
  },

  countNew(searchId) {
    return db.prepare('SELECT COUNT(*) AS c FROM results WHERE search_id = ? AND is_new = 1').get(searchId).c;
  },
};

module.exports = ResultRepo;