// Operazioni su `scan_history`.
'use strict';

const db = require('../Database');

const ScanRepo = {
  create(searchId) {
    return db.prepare('INSERT INTO scan_history (search_id, started_at) VALUES (?, strftime(\'%s\',\'now\'))').run(searchId);
  },

  finish(id, { results_found, new_found, errors, status }) {
    return db.prepare(`
      UPDATE scan_history
      SET finished_at = strftime('%s','now'),
          results_found = ?,
          new_found = ?,
          errors = ?,
          status = ?
      WHERE id = ?
    `).run(results_found, new_found, errors, status, id);
  },

  recent(limit = 20) {
    return db.prepare('SELECT * FROM scan_history ORDER BY id DESC LIMIT ?').all(limit);
  },
};

module.exports = ScanRepo;