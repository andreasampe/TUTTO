// Database SQLite in un file locale. Niente server, niente cloud.
'use strict';

const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, '..', '..', 'data', 'finder.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS sources (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,
  url           TEXT    NOT NULL,
  type          TEXT    NOT NULL,
  method        TEXT    NOT NULL,
  frequency     INTEGER NOT NULL DEFAULT 3600,
  enabled       INTEGER NOT NULL DEFAULT 1,
  last_check    INTEGER,
  last_error    TEXT,
  created_at    INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS searches (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT    NOT NULL,
  keyword     TEXT    NOT NULL,
  frequency   INTEGER NOT NULL DEFAULT 1800,
  enabled     INTEGER NOT NULL DEFAULT 1,
  created_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS search_sources (
  search_id INTEGER NOT NULL,
  source_id INTEGER NOT NULL,
  PRIMARY KEY (search_id, source_id),
  FOREIGN KEY (search_id) REFERENCES searches(id) ON DELETE CASCADE,
  FOREIGN KEY (source_id) REFERENCES sources(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS results (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  search_id    INTEGER,
  source_id    INTEGER,
  title        TEXT,
  url          TEXT    NOT NULL,
  snippet      TEXT,
  published_at INTEGER,
  detected_at  INTEGER NOT NULL DEFAULT (strftime('%s','now')),
  is_new       INTEGER NOT NULL DEFAULT 0,
  UNIQUE (search_id, url),
  FOREIGN KEY (search_id) REFERENCES searches(id) ON DELETE CASCADE,
  FOREIGN KEY (source_id) REFERENCES sources(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS scan_history (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  search_id     INTEGER,
  started_at    INTEGER,
  finished_at   INTEGER,
  results_found INTEGER NOT NULL DEFAULT 0,
  new_found     INTEGER NOT NULL DEFAULT 0,
  errors        INTEGER NOT NULL DEFAULT 0,
  status        TEXT,
  FOREIGN KEY (search_id) REFERENCES searches(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS notifications (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  type       TEXT    NOT NULL,
  title      TEXT,
  body       TEXT,
  "read"     INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS search_history (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  search_id     INTEGER,
  keyword       TEXT,
  executed_at   INTEGER NOT NULL DEFAULT (strftime('%s','now')),
  results_count INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY (search_id) REFERENCES searches(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_results_url ON results(url);
CREATE INDEX IF NOT EXISTS idx_results_detected ON results(detected_at);
CREATE INDEX IF NOT EXISTS idx_results_search ON results(search_id);
CREATE INDEX IF NOT EXISTS idx_sources_enabled ON sources(enabled);
CREATE INDEX IF NOT EXISTS idx_scan_history_search ON scan_history(search_id);
`;

db.exec(SCHEMA);

module.exports = db;