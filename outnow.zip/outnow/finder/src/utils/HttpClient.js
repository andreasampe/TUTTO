// Client HTTP con timeout, retry e limitazione delle dimensioni. Niente fetch esterno.
'use strict';

const https = require('https');
const http = require('http');
const { URL } = require('url');

const DEFAULT_TIMEOUT = 15000;
const MAX_BYTES = 2 * 1024 * 1024; // 2 MB
const MAX_RETRIES = 2;

function request(url, { timeout = DEFAULT_TIMEOUT, maxBytes = MAX_BYTES, retries = MAX_RETRIES, signal } = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === 'https:' ? https : http;

    const attempt = (left) => {
      const req = lib.get(u, { timeout }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          // redirect limitato a 1 salto
          if (left <= 0) return reject(new Error(`Troppi redirect per ${url}`));
          return attempt(left - 1);
        }

        const chunks = [];
        let total = 0;
        res.on('data', (chunk) => {
          total += chunk.length;
          if (total > maxBytes) {
            req.destroy(new Error(`Risposta troppo grande (> ${maxBytes} bytes)`));
            return;
          }
          chunks.push(chunk);
        });
        res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
        res.on('error', reject);
      });

      req.on('timeout', () => { req.destroy(new Error(`Timeout per ${url}`)); });
      req.on('error', (err) => {
        if (left > 0) return attempt(left - 1);
        reject(err);
      });
      if (signal) {
        signal.addEventListener('abort', () => req.destroy(new Error('Operazione annullata')));
      }
    };

    attempt(retries);
  });
}

async function fetchText(url, opts) {
  const res = await request(url, opts);
  return res.body.toString('utf8');
}

module.exports = { request, fetchText };