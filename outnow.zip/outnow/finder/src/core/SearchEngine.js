// Motore di ricerca centrale. Interroga le fonti attive, deduplica, ordina.
'use strict';

const SourceFactory = require('../sources/SourceFactory');
const ResultRepo = require('../db/repos/ResultRepo');
const SourceRepo = require('../db/repos/SourceRepo');
const NotificationRepo = require('../db/repos/NotificationRepo');
const ScanRepo = require('../db/repos/ScanRepo');

class SearchEngine {
  // Cerca `keyword` su tutte le fonti attive (o su quelle specificate).
  async search(keyword, { sourceIds = null, limit = 50 } = {}) {
    const sources = sourceIds
      ? sourceIds.map((id) => SourceRepo.findById(id)).filter(Boolean)
      : SourceRepo.enabled();

    const results = [];
    const errors = [];

    // Interroga le fonti in parallelo: un errore su una non ferma le altre.
    await Promise.all(sources.map(async (s) => {
      try {
        const src = SourceFactory.create(s);
        const found = await src.search(keyword);
        for (const r of found) {
          results.push({
            search_id: null,
            source_id: s.id,
            title: r.title,
            url: r.url,
            snippet: r.snippet || keyword,
            published_at: r.published_at,
          });
        }
      } catch (err) {
        errors.push({ sourceId: s.id, error: err.message });
      }
    }));

    const deduped = this.deduplicate(results);
    deduped.sort((a, b) => (b.detected_at || 0) - (a.detected_at || 0));
    return { results: deduped.slice(0, limit), errors };
  }

  deduplicate(list) {
    const seen = new Set();
    return list.filter((r) => {
      const key = r.url;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
}

module.exports = SearchEngine;