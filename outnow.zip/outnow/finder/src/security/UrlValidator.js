// Protezione da URL malevoli e SSRF. Niente richieste a server privati/loopback.
'use strict';

const dns = require('dns/promises');

const BLOCKED_HOSTS = new Set([
  'localhost', '127.0.0.1', '::1', '0.0.0.0',
  'metadata.google.internal', '169.254.169.254',
]);

const PRIVATE_RANGES = [
  (ip) => ip.startsWith('10.'),
  (ip) => ip.startsWith('192.168.'),
  (ip) => ip.startsWith('172.1') || ip.startsWith('172.12.') || ip.startsWith('172.13.'),
  (ip) => ip.startsWith('172.14.') || ip.startsWith('172.15.') || ip.startsWith('172.16.'),
  (ip) => ip.startsWith('172.17.') || ip.startsWith('172.18.') || ip.startsWith('172.19.'),
  (ip) => ip.startsWith('172.2') || ip.startsWith('172.3'),
  (ip) => ip === '127.0.0.1' || ip === '::1',
];

function isPrivateIp(ip) {
  return PRIVATE_RANGES.some((fn) => fn(ip));
}

function isBlockedHost(host) {
  const h = host.toLowerCase();
  return BLOCKED_HOSTS.has(h) || h.endsWith('.local') || h.endsWith('.internal');
}

async function validate(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error(`URL non valido: ${url}`);
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error(`Schema non supportato per ${url}: ${parsed.protocol}`);
  }

  const host = parsed.hostname;
  if (!host) throw new Error(`URL senza host: ${url}`);
  if (isBlockedHost(host)) throw new Error(`Host bloccato (privato/loopback): ${host}`);

  // Risolvi il DNS e blocca indirizzi privati (SSRF via DNS rebinding)
  const addresses = await dns.lookup(host, { all: true });
  for (const a of addresses) {
    if (isPrivateIp(a.address)) throw new Error(`Indirizzo privato bloccato per ${host}: ${a.address}`);
  }

  return parsed;
}

module.exports = { validate, isBlockedHost, isPrivateIp };