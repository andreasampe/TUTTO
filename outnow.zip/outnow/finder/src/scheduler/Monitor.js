// Monitor: esegue le ricerche salvate con la frequenza impostata, salva i nuovi risultati
// e genera notifiche. Un errore su una ricerca non blocca le altre.
'use strict';

const SearchRepo = require('../db/repos/SearchRepo');
const ResultRepo = require('../db/repos/ResultRepo');
const SourceRepo = require('../db/repos/SourceRepo');
const ScanRepo = require('../db/repos/ScanRepo');
const NotificationRepo = require('../db/repos/NotificationRepo');
const SourceFactory = require('../sources/SourceFactory');

class Monitor {
  constructor() {
    this.running = new Set();
  }

  async runSearch(search) {
    if (this.running.has(search.id)) return;
    this.running.add(search.id);

    const scan = ScanRepo.create(search.id);
    let resultsFound = 0;
    let newFound = 0;
    let errors = 0;
    let status = 'ok';

    try {
      const sources = SourceRepo.all().filter((s) => {
        const ids = (search.source_ids || '').split(',').map(Number).filter(Boolean);
        return ids.length === 0 || ids.includes(s.id);
      });

      for (const s of sources) {
        try {
          const src = SourceFactory.create(s);
          const found = await src.search(search.keyword);
          for (const r of found) {
            const res = ResultRepo.upsert({
              search_id: search.id,
              source_id: s.id,
              title: r.title,
              url: r.url,
              snippet: r.snippet || search.keyword,
              published_at: r.published_at,
            });
            resultsFound++;
            if (res.changes === 1) newFound++;
          }
          SourceRepo.setLastCheck(s.id, null);
        } catch (err) {
          errors++;
          SourceRepo.setLastCheck(s.id, err.message);
          NotificationRepo.add({
            type: 'source_error',
            title: `Fonte non raggiungibile: ${s.name}`,
            body: err.message,
          });
        }
      }

      if (newFound > 0) {
        NotificationRepo.add({
          type: 'new_result',
          title: `Nuovi risultati per "${search.name}"`,
          body: `${newFound} nuovi risultati trovati su ${resultsFound} totali.`,
        });
      }
    } catch (err) {
      errors++;
      status = 'error';
      NotificationRepo.add({
        type: 'scan_error',
        title: `Errore nella ricerca "${search.name}"`,
        body: err.message,
      });
    } finally {
      ScanRepo.finish(scan.lastInsertRowid, { results_found: resultsFound, new_found: newFound, errors, status });
      SearchRepo.insertHistory(search.id, search.keyword, resultsFound);
      this.running.delete(search.id);
    }
  }

  async runAll() {
    const searches = SearchRepo.all().filter((s) => s.enabled === 1);
    await Promise.all(searches.map((s) => this.runSearch(s)));
  }

  // Esegui una ricerca subito, indipendentemente dalla frequenza.
  async runNow(searchId) {
    const search = SearchRepo.findById(searchId);
    if (!search) throw new Error(`Ricerca ${searchId} non trovata`);
    return this.runSearch(search);
  }
}

module.exports = Monitor;