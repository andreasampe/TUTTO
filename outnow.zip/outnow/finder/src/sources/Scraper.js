// Fonte: pagina pubblica consultabile (deltabit, maxfri, mixdrop, cloud aperti).
// Cerca il keyword nella pagina e restituisce i link trovati.
'use strict';

const Source = require('./Source');
const { fetchText } = require('../utils/HttpClient');
const UrlValidator = require('../security/UrlValidator');

const LINK_RE = /href="([^"]+)"/g;

function normalizeUrl(raw, base) {
  try {
    const u = new URL(raw, base);
    u.hash = '';
    if (u.pathname.endsWith('/')) u.pathname = u.pathname.slice(0, -1);
    return `${u.origin}${u.pathname}${u.search}`;
  } catch {
    return null;
  }
}

class Scraper extends Source {
  constructor(opts) {
    super(opts);
    this.type = 'scraper';
    this.method = 'scraper';
  }

  async testReachability() {
    try {
      await UrlValidator.validate(this.url);
      const res = await fetchText(this.url, { timeout: 12000, maxBytes: 1024 * 1024 });
      return { ok: true, status: 200, bytes: res.length };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  }

  async search(keyword) {
    const html = await fetchText(this.url, { timeout: 20000, maxBytes: 2 * 1024 * 1024 });
    const results = [];
    const seen = new Set();
    let m;
    while ((m = LINK_RE.exec(html)) !== null) {
      const link = normalizeUrl(m[1], this.url);
      if (!link || seen.has(link)) continue;
      if (!link.startsWith('http')) continue;
      seen.add(link);
      results.push({
        title: link,
        url: link,
        snippet: keyword,
        published_at: null,
      });
    }
    return results;
  }

  async collectLatest() {
    return this.search('');
  }
}

module.exports = Scraper;