// Mappa tipo/fonte -> classe. Aggiungere una nuova fonte = aggiungere una voce qui.
'use strict';

const Scraper = require('./Scraper');
const Dropbox = require('./Dropbox');

const CLASSES = {
  scraper: Scraper,
  page: Scraper,
  dropbox: Dropbox,
};

function create(opts) {
  const Cls = CLASSES[opts.type] || CLASSES[opts.method] || Scraper;
  return new Cls(opts);
}

module.exports = { create, CLASSES };