// Interfaccia di una fonte. Ogni fonte implementa questi tre metodi.
// Aggiungere una nuova fonte = aggiungere un file qui, niente modifica al motore.
'use strict';

class Source {
  constructor({ id, name, url, type, method, frequency }) {
    this.id = id;
    this.name = name;
    this.url = url;
    this.type = type;
    this.method = method;
    this.frequency = frequency;
  }

  // Restituisce { ok: true } oppure { ok: false, error: '...' }
  async testReachability() { throw new Error('testReachability non implementato'); }

  // Cerca `keyword` e restituisce un array di risultati
  async search(keyword) { throw new Error('search non implementato'); }

  // Raccolta automatica periodica: risultati nuovi senza parola chiave
  async collectLatest() { return []; }

  // Opzionale: url di test per la verifica
  testUrl() { return this.url; }
}

module.exports = Source;