// FINDER — punto di ingresso.
// Avvia il server HTTP in locale. Niente cloud, niente servizi esterni.
'use strict';

const http = require('./src/http/Server');

const PORT = process.env.FINDER_PORT || 3000;

http.listen(PORT, () => {
  console.log(`[FINDER] http://localhost:${PORT}`);
  console.log('[FINDER] Premi Ctrl+C per fermare.');
});